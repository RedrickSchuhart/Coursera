#pragma once

#include <future>
#include <istream>
#include <ostream>
#include <set>
#include <list>
#include <vector>
#include <map>
#include <string>
using namespace std;

template <typename V>
struct Access {
  lock_guard<mutex> guard;
  V& ref_to_value;
};

class InvertedIndex {
public:
  mutex m;
  void Add(const string& document);
  vector<size_t> Lookup(const string& word) const;

  size_t GetSize() const {
      return docs.size();
  }

  const string& GetDocument(size_t id) const {
    return docs[id];
  }

  void Clear(){
      index.clear();
      docs.clear();
  }

private:
  map<string, vector<size_t>> index;
  vector<string> docs;
};

class SearchServer {
public:
  SearchServer() = default;
  explicit SearchServer(istream& document_input);
  void UpdateDocumentBase(istream& document_input);
  void AddQueriesStream(istream& query_input, ostream& search_results_output);
  template <typename Container>
  void AddSingleQueriesStream(ostream& search_results_output, mutex& output, const Container& words);

private:
  InvertedIndex index;
};
